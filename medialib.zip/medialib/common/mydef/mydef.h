#ifndef __MYDEF_H__
#define __MYDEF_H__

BOOL is_file_exist(const char* filename);

void generate_rand_32bit(UINT32& rand_num);

#endif // __MYDEF_H__