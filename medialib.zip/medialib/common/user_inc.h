#ifndef __USER_INC_H__
#define __USER_INC_H__

#include "typedef.h"
#include "mydef.h"
#include "mylog.h"
#include "redis_queue.h"
#include "base_sync_task.h"
#include "async_task.h"
#include "shared_data.h"

#endif // __USER_INC_H__