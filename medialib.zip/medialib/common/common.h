#ifndef __COMMON_H__
#define __COMMON_H__

#include "err_code.h"
#include "system_inc.h"
#include "user_inc.h"

//#endif // __COMMON_H__
#endif