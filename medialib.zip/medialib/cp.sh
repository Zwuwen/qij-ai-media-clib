scp ./libqjmedia.so root@192.168.55.121:/usr/lib
#sudo cp ./libqjmedia.so /usr/lib

