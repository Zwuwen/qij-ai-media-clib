#ifndef __DATA_DEF_H__
#define __DATA_DEF_H__

//typedef struct _redis_key_info
//{
//    std::string m_ctrl_key;
//    std::string m_data_key;
//    struct _redis_key_info& operator=(struct _redis_key_info info)
//    {
//        this->m_ctrl_key = info.m_ctrl_key;
//        this->m_data_key = info.m_data_key;
//        return *this;
//    }
//}redis_key_info_t;
//
#endif